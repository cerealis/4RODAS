<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wpquatrorodas');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'islanislaven@4');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         ']-Fs ^}!-~Rgo]N&}3x|}S]5-$5USU-py;~[I2OWBC0~UsO~Y.dimg|z]9y*YMPE');
define('SECURE_AUTH_KEY',  'la @q{6P9Tp7],8 h`P@](C=$YrrMRZ(b.0lL2p=Eb2MMBDXI{bXMFDgtk^<kt)Q');
define('LOGGED_IN_KEY',    ') -$>ex6S+#}#{O|-GU+<10^g%$ITRhqeTHY-~cui[&Yv.,Z#f,,1T}2`M }!?tV');
define('NONCE_KEY',        'Y=DExg;S8q_m;9V4Clq$jSEu&=q--z&9wE8[[[pyy?]k`a;Qu~Zc(KjL_|#{;YA:');
define('AUTH_SALT',        '33A_h-p[#B3GY[D?IshS*6Y_DCc|m{j)h^dX@}y$j~ vi!K=#1{zZZd *<Dau,m~');
define('SECURE_AUTH_SALT', '3:qS-`G}_7+W]@K^GiIHM;CpXIOBl*27NHKqJUDevXBRx(FmZX1|`X-%p{Gob*,-');
define('LOGGED_IN_SALT',   'H/w2jy?~.z!]1VJg+{N]M~ObY!/)7rX-.,&/vF.)v*uE|8#ABR4wgegd-kL:42VZ');
define('NONCE_SALT',       '~n+[`woOwsAm;UN^+#yj&l8~);dB6N@Rn.p-RaMCbTWs/x~VqIDVr?8r?915CpUD');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
